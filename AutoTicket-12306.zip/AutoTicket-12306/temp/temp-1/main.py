import time
import requests
from prettytable import PrettyTable
import json
from DrissionPage import ChromiumPage
from DrissionPage.common import Actions, Keys
from password import account, Password
from pypinyin import pinyin, Style

def change(chinese):
    text = pinyin(chinese, style=Style.NORMAL)
    string = ''.join([t[0] for t in text])
    return string

def login(dp, ac):
    text = dp.ele('css:#login_user').text
    if text == '登录':
        dp.ele('css:#J-userName').input(account)
        dp.ele('css:#J-password').input(Password)
        dp.ele('css:#J-login').click()
        time.sleep(0.5)
        dp.ele('css:#id_card').input('4036')
        dp.ele('css:#verification_code').click()
        code = input('输入验证码：')
        dp.ele('css:#code').input(code)
        dp.ele('css:#sureClick').click()
    else:
        print('账号已登录')

def select_passengers(dp, passengers):
    for passenger in passengers:
        passenger_id = f'normalPassenger_{passenger.strip()}'
        for _ in range(3):  # 尝试3次
            try:
                dp.ele(f'css:#{passenger_id}').click()
                break
            except Exception as e:
                print(f"选择乘车人 {passenger_id} 失败，重试中...")
                time.sleep(1)
        else:
            print(f"选择乘车人 {passenger_id} 失败，放弃重试。")

def choose_ticket_type(dp, ticket_type):
    try:
        if ticket_type == '学生票':
            dp.ele('css:#dialog_xsertcj_ok').click()
        else:
            dp.ele('css:#dialog_xsertcj_cancel').click()
    except Exception as e:
        print(f"选择票种 {ticket_type} 失败，错误信息：{e}")

def select_seats(dp, num_passengers):
    try:
        seat_map = {
            1: ['F'],
            2: ['D', 'F'],
            3: ['A', 'B', 'C'],
            4: ['A', 'B', 'C', 'D'],
            5: ['A', 'B', 'C', 'D', 'F']
        }
        seats = seat_map.get(num_passengers, [])
        for seat in seats:
            dp.ele(f'css:a[id$="{seat}"]').click()
    except Exception as e:
        print(f"选择座位失败，错误信息：{e}")

def submit_order(dp, num_passengers):
    dp.ele('css:#submitOrder_id').click()
    time.sleep(1)
    if dp.ele_exists('css:#content_checkticketinfo_id'):
        select_seats(dp, num_passengers)
        dp.ele('css:#qr_submit_id').click()
    else:
        dp.ele('css:#qr_submit_id').click()
    dp.ele('css:#payButton').click()
    dp.ele('css:#continuePay').click()

def Buy(FromCity, ToCity, Date, Num, passengers, ticket_type):
    dp = ChromiumPage()
    ac = Actions(dp)
    dp.get('https://kyfw.12306.cn/otn/leftTicket/init')
    ac.move_to('css:#fromStationText').click().type(change(FromCity))
    dp.ele('css:#fromStationText').input(Keys.ENTER)
    ac.move_to('css:#toStationText').click().type(change(ToCity))
    dp.ele('css:#toStationText').input(Keys.ENTER)
    dp.ele('css:#train_date').clear()
    dp.ele('css:#train_date').input(Date)
    dp.ele('css:#query_ticket').click()
    dp.ele(f'css:#queryLeftTable tr:nth-child({int(Num) * 2 - 1}) .btn72').click()
    login(dp, ac)
    time.sleep(1)
    select_passengers(dp, passengers)
    choose_ticket_type(dp, ticket_type)
    submit_order(dp, len(passengers))

f = open('city.json', encoding='utf-8').read()
city_data = json.loads(f)

from_city = input('输入出发的城市：')
to_city = input('输入到达的城市：')
train_date = input('输入出发的日期（格式：2024-10-08）：')
# train_date = '2024-10-08'

headers = {
    'cookie': '_uab_collina=171767320415607602884332; JSESSIONID=C8D997A9EBF25071C77200B5319717D4; '
              '_jc_save_wfdc_flag=dc; BIGipServerotn=2698445066.50210.0000; BIGipServerpassport=921174282.50215.0000; '
              'guidesStatus=off; highContrastMode=defaltMode; cursorStatus=off; '
              'route=6f50b51faa11b987e576cdb301e545c4; _jc_save_fromStation=%u5E7F%u5DDE%u5357%2CIZQ; '
              '_jc_save_toStation=%u6F6E%u9633%2CCNQ; _jc_save_toDate=2024-09-30; _jc_save_fromDate=2024-10-08',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 '
                  'Safari/537.36'
}

url = f'https://kyfw.12306.cn/otn/leftTicket/queryG?leftTicketDTO.train_date={train_date}&leftTicketDTO.from_station={city_data[from_city]}&leftTicketDTO.to_station={city_data[to_city]}&purpose_codes=ADULT'
response = requests.get(url=url, headers=headers)
json_data = response.json()
result = json_data['data']['result']

page = 1
tb = PrettyTable()
tb.field_names = [
    '序号',
    '车次',
    '出发站',
    '到达站',
    '出发时间',
    '到达时间',
    '耗时',
    '特等/商务座',
    '一等座',
    '二等座',
    '软卧',
    '硬卧',
    '硬座',
    '无座'
]

for i in result:
    index = i.split('|')
    num = index[3]
    start_station = index[4]
    arrived_station = index[5]
    start_time = index[8]
    end_time = index[9]
    use_time = index[10]
    topGrade = index[32]
    first_class = index[31]
    second_class = index[30]
    hard_sleeper = index[28]
    hard_seat = index[29]
    no_seat = index[26]
    soft_sleeper = index[23]

    tb.add_row([
        page,
        num,
        start_station,
        arrived_station,
        start_time,
        end_time,
        use_time,
        topGrade,
        first_class,
        second_class,
        hard_sleeper,
        hard_seat,
        no_seat,
        soft_sleeper
    ])
    page += 1
print(tb)

page_num = input('输入购买的车次序号：')
passengers = input('输入乘车人序号（用逗号分隔）：').split(',')
ticket_type = input('输入票种（成人票/学生票）：')
Buy(FromCity=from_city, ToCity=to_city, Date=train_date, Num=page_num, passengers=passengers, ticket_type=ticket_type)
