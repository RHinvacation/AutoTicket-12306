# 导入数据请求模块
import time

import requests
# 导入制表模块
from prettytable import PrettyTable
# 导入json模块
import json
# 导入自动化模块
from DrissionPage import ChromiumPage
# 导入动作链
from DrissionPage.common import Actions
# 导入键盘操作
from DrissionPage.common import Keys
# 导入账号密码
from password import account, Password
# 导入拼音模块
from pypinyin import pinyin, Style


def change(chinese):
    # 把中文转成拼音
    text = pinyin(chinese, style=Style.NORMAL)
    string = ''.join([t[0] for t in text])
    print(string)
    return string


change('广州南')


def Buy(FromCity, ToCity, Date, Num):
    # 打开浏览器 -> 实例化浏览器对象
    dp = ChromiumPage()
    ac = Actions(dp)
    # # 访问网站
    dp.get('https://kyfw.12306.cn/otn/leftTicket/init')
    # 定位出发城市的输入框，进行输入
    ac.move_to('css:#fromStationText').click().type(change(FromCity))
    dp.ele('css:#fromStationText').input(Keys.ENTER)
    # dp.ele('css:#fromStationText').clear()  # 清除
    # dp.ele('css:#fromStationText').input('广州')
    # 定位目的城市的输入框，进行输入
    ac.move_to('css:#toStationText').click().type(change(ToCity))
    dp.ele('css:#toStationText').input(Keys.ENTER)
    # dp.ele('css:#toStationText').clear()  # 清除
    # dp.ele('css:#toStationText').input('汕头')
    # 定位出发日期的输入框，进行输入
    dp.ele('css:#train_date').clear()  # 清除
    dp.ele('css:#train_date').input(Date)
    # 点击查询按钮
    dp.ele('css:#query_ticket').click()
    # 点击预定按钮
    dp.ele(f'css:#queryLeftTable tr:nth-child({int(Num) * 2 - 1}) .btn72').click()

    # 1.判断是否有登录账号
    text = dp.ele('css:#login_user').text
    if text == '登录':
        # 输入账号
        dp.ele('css:#J-userName').input(account)
        # 输入密码
        dp.ele('css:#J-password').input(Password)
        # 点击确定登录
        dp.ele('css:#J-login').click()
        time.sleep(0.5)  # 延时
        dp.ele('css:#id_card').input('4036')  # 身份证后四位
        dp.ele('css:#verification_code').click()
        code = input('输入验证码：')
        dp.ele('css:#code').input(code)
        dp.ele('css:#sureClick').click()
    else:
        print('账号已登录')
    time.sleep(1)  # 延时

    dp.ele('css:#normalPassenger_0').click()  # 选择乘车人
    # dp.ele('css:#dialog_xsertcj_cancel').click()  # 成人票
    # dp.ele('css:#dialog_xsertcj_ok').click()  # 学生票
    # dp.ele('css:#1F').click()  # 选座位，F座
    # dp.ele('css:#1A').click()  # 选座位，A座

    dp.ele('css:#submitOrder_id').click()  # 提交订单
    dp.ele('css:#qr_submit_id').click()  # 确认提交订单

    dp.ele('css:#payButton').click()  # 网上支付
    dp.ele('css:#continuePay').click()  # 取消购买铁路乘意险


#  “根据用户自行输入相关信息，进行查票搜索”
# 1.读取城市文件
f = open('city.json', encoding='utf-8').read()
# 把json字符串数据，转成json字典
city_data = json.loads(f)
print(city_data)

# 输入出发城市
from_city = input('输入出发的城市：')
# 输入目的城市
to_city = input('输入到达的城市：')
# 输入出行日期
train_date = '2024-10-08'
print(city_data[from_city])
print(city_data[to_city])

# “发送请求”
# 1.模拟浏览器 -> 防反爬手段
headers = {
    # cookie 用户信息
    'cookie': '_uab_collina=171767320415607602884332; JSESSIONID=C8D997A9EBF25071C77200B5319717D4; '
              '_jc_save_wfdc_flag=dc; BIGipServerotn=2698445066.50210.0000; BIGipServerpassport=921174282.50215.0000; '
              'guidesStatus=off; highContrastMode=defaltMode; cursorStatus=off; '
              'route=6f50b51faa11b987e576cdb301e545c4; _jc_save_fromStation=%u5E7F%u5DDE%u5357%2CIZQ; '
              '_jc_save_toStation=%u6F6E%u9633%2CCNQ; _jc_save_toDate=2024-09-30; _jc_save_fromDate=2024-10-08',
    # user-agent 用户代理，表示浏览器/设备 基本身份信息
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 '
                  'Safari/537.36'
}
# 2.请求网址
url = f'https://kyfw.12306.cn/otn/leftTicket/queryG?leftTicketDTO.train_date={train_date}&leftTicketDTO.from_station={city_data[from_city]}&leftTicketDTO.to_station={city_data[to_city]}&purpose_codes=ADULT'
# 3.发送请求
response = requests.get(url=url, headers=headers)

# “获取数据”
# 1.获取响应的json数据 -> 字典数据类型
json_data = response.json()

# 2.解析数据
# 2-1.字典取值：提取车次信息所在列表 result
result = json_data['data']['result']
# 2-2.定义序号
page = 1
# 2-3实例化对象
tb = PrettyTable()
# 2-4设置字段名
tb.field_names = [
    '序号',
    '车次',
    '出发时间',
    '到达时间',
    '耗时',
    '特等/商务座',
    '一等座',
    '二等座',
    '软卧',
    '硬卧',
    '硬座',
    '无座'
]
# 2-5.for循环遍历，提取列表里的元素内容
for i in result:
    # 字符串分割
    index = i.split('|')
    # 通过列表索引位置取值
    # # 确认索引位置
    # index_page = 0
    # for j in index:
    #     print(j, page, sep=' 索引是-->')
    #     index_page += 1
    # break
    num = index[3]  # 车次
    start_time = index[8]  # 出发时间
    end_time = index[9]  # 到达时间
    use_time = index[10]  # 耗时

    topGrade = index[32]  # 特等/商务座
    first_class = index[31]  # 一等座
    second_class = index[30]  # 二等座

    hard_sleeper = index[28]  # 硬卧
    hard_seat = index[29]  # 硬座
    no_seat = index[26]  # 无座
    soft_sleeper = index[23]  # 软卧

    dit = {
        '车次': num,
        '出发时间': start_time,
        '到达时间': end_time,
        '耗时': use_time,
        '特等/商务座': topGrade,
        '一等座': first_class,
        '二等座': second_class,
        '软卧': soft_sleeper,
        '硬卧': hard_sleeper,
        '硬座': hard_seat,
        '无座': no_seat,
    }
    # 添加数据内容
    tb.add_row([
        page,
        num,
        start_time,
        end_time,
        use_time,
        topGrade,
        first_class,
        second_class,
        hard_sleeper,
        hard_seat,
        no_seat,
        soft_sleeper
    ])
    page += 1
print(tb)

#  买票
page_num = input('输入购买的车次序号：')
Buy(FromCity=from_city, ToCity=to_city, Date=train_date, Num=page_num)
