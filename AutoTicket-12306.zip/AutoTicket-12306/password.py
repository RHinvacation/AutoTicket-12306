# 你的12306账号
account = 'your account'

# 你的12306密码
Password = 'your password'

